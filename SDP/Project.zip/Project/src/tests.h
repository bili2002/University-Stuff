#include "trip.h"
#include "city.h"
#include "box.h"

namespace Tests {
    void testTrip();
    void testCity();
    void testBox();
};

